# R-Theory Working Notes

This directory preserves exploratory calculations and historical worksheets separately from the canonical S Essay corpus.

## Trig2

- [`Trig2.pdf`](Trig2.pdf) - eight-page spreadsheet export containing operator definitions, identity calculations, phase-sector tables, sample values, and working commentary.
- [`Trig2-extracted.txt`](Trig2-extracted.txt) - machine-searchable text extraction from the PDF.

The worksheet is **noncanonical working material**. It contains historical terminology, superseded composite operators, unresolved spreadsheet errors, and passages where interpretation is mixed with mathematics. In particular:

- the current convention is `uxp(x) = cxp(x) - sxp(x)`;
- the former `krx/kxp` composites are not part of the current canonical operator set;
- statements about entropy, spacetime, cosmology, mirror universes, or biological meaning are hypotheses unless supplied with a declared projection contract and empirical test;
- boundary rows marked zero, infinity, or superposition are exploratory annotations rather than values of the original functions at excluded points.

The strongest mathematical content in the worksheet is preserved and formalized in the S Essays, including the reciprocal pairs and the identity

`urx(x) + uxp(x) = 4 / sin(2x)`

on the admissible domain where the relevant denominators are nonzero.
