# Projection Craft S Essays

This directory is the publication index for the **Projection Craft S Essays**, the rigorous mathematical and projection-methodology series developed from the R-Theory operator framework.

## Current S0-S1 editions

The repository root already contains the ambiguity-resolved source and compiled edition:

- [`Projection_Craft_S0-S1_Ambiguity_Resolved.tex`](../Projection_Craft_S0-S1_Ambiguity_Resolved.tex) - LaTeX source.
- [`Projection_Craft_S0-S1_Ambiguity_Resolved.pdf`](../Projection_Craft_S0-S1_Ambiguity_Resolved.pdf) - compiled ambiguity-resolved edition.

This directory adds:

- [`Projection_Craft_S0-S1_Complete.pdf`](Projection_Craft_S0-S1_Complete.pdf) - 533-page complete source edition.

SHA-256 for the complete edition:

`97804427b5880a08620950d98dd4775664509b1ad1bffa1149dd3dd03472a6a0`

## Book 0 - Formal Core

- **S0.I - The Pythagorean Foundation of the Bounded Phase Operators**
- **S0.II - The Canonical Generator and Quadrant-Local Closure**
- **S0.III - Tangential Geometry and Bounded Transfer**
- **S0.IV - Phase Symmetry, Operator Orbits, and Octant Rotation**
- **S0.V - Boundary Structure, Singular Limits, and Admissible Extension**
- **S0.VI - Axiomatic Status, Minimality, and the Book 0 Theorem Ledger**

Book 0 establishes the exact trigonometric operator identities, reciprocal structure, one-generator quadrant-local reduction, differential closure, bounded transfer system, symmetry action, and boundary ledger. It deliberately does **not** treat physical interpretation as mathematically proved.

## Book 1 - Projection Discipline

- **S1.I - Structural and Projection Layers**
- **S1.II - Projection Contracts and Failure Witnesses**
- **S1.III - Measurement Protocols, Error, and Uncertainty**
- **S1.IV - Calibration and Dimensional Readout**
- **S1.V - Projection Equivalence and Model Comparison**

Book 1 specifies how dimensionless structure may be connected to observables without silently importing units, constants, ontology, or empirical conclusions.

## Canonical status

The ambiguity-resolved S0-S1 edition is the stable foundational corpus. Later books should preserve it and record corrections, limitations, or extensions prospectively through commentary, errata, extension ledgers, and cross-references rather than silently rewriting foundational claims.

Historical calculations and exploratory notes are kept separately under [`working-notes/`](../working-notes/) so that provisional material is not confused with the proved S Essay corpus.
