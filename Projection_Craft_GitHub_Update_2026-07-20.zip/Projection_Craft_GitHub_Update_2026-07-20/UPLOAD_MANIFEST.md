# GitHub Update Manifest - 2026-07-20

Target repository: `kitcosby/rtheory-`

## Existing files verified unchanged

The following uploaded files already exist in the repository and match byte-for-byte, so they should not be uploaded again:

- `Projection_Craft_S0-S1_Ambiguity_Resolved.tex`
  - Git blob SHA: `ce11f523e2d13fc76ab590f8f88083b4f328ab8a`
  - SHA-256: `911707862420851d451db058eef37255c77c937cd5836d655b07fe3d4f2b5e2e`
- `Projection_Craft_S0-S1_Ambiguity_Resolved.pdf`
  - Git blob SHA: `3c25e8e2a69aa9a8b2cbd0e2d203813f05eec6d8`
  - SHA-256: `f37471636f09f0757052ab9b599ccfcc0f949e697d848adafa9d062f29d0b15b`

## New repository paths

Upload these files while preserving their paths:

- `S-Essays/README.md`
- `S-Essays/Projection_Craft_S0-S1_Complete.pdf`
- `working-notes/README.md`
- `working-notes/Trig2.pdf`
- `working-notes/Trig2-extracted.txt`

Then prepend the contents of `README_SECTION_TO_PREPEND.md` to the repository root `README.md`.

## New binary checksums

- `S-Essays/Projection_Craft_S0-S1_Complete.pdf`
  - 533 pages
  - SHA-256: `97804427b5880a08620950d98dd4775664509b1ad1bffa1149dd3dd03472a6a0`
- `working-notes/Trig2.pdf`
  - 8 pages
  - SHA-256: `afcd02816ffb93f24dc267fe76c8e8f178b4f0e233f97103f783422534659be7`

## Suggested commit message

`Add S Essays complete edition and working notes`
