## Current publication corpus

The rigorous public corpus is now organized as the **Projection Craft S Essays**.

- [S Essays index](S-Essays/README.md)
- [S0-S1 complete edition](S-Essays/Projection_Craft_S0-S1_Complete.pdf)
- [Ambiguity-resolved LaTeX source](Projection_Craft_S0-S1_Ambiguity_Resolved.tex)
- [Ambiguity-resolved compiled edition](Projection_Craft_S0-S1_Ambiguity_Resolved.pdf)
- [Historical and exploratory working notes](working-notes/README.md)

The S Essays separate proved mathematics from projection rules, empirical claims, and interpretation. Book 0 supplies the formal operator core; Book 1 supplies the discipline for connecting structure to measurement.

---

