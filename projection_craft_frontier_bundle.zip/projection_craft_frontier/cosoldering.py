from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from .linear import matrix_rank, nullspace
from .types import GateResult, GateStatus

Array = NDArray[np.float64]


def vec_index(mu: int, nu: int, n: int = 4) -> int:
    return mu * n + nu


def symmetric_embedding(n: int = 4) -> Array:
    """Map the n(n+1)/2 independent symmetric entries into vec(f_mu_nu)."""
    cols = []
    for mu in range(n):
        for nu in range(mu, n):
            m = np.zeros((n, n), dtype=float)
            if mu == nu:
                m[mu, nu] = 1.0
            else:
                m[mu, nu] = 1.0
                m[nu, mu] = 1.0
            cols.append(m.reshape(-1))
    return np.column_stack(cols)


def antisymmetric_embedding(n: int = 4) -> Array:
    cols = []
    for mu in range(n):
        for nu in range(mu + 1, n):
            m = np.zeros((n, n), dtype=float)
            m[mu, nu] = 1.0
            m[nu, mu] = -1.0
            cols.append(m.reshape(-1))
    return np.column_stack(cols)


def antisymmetric_extractor(n: int = 4) -> Array:
    """A vec(f) = independent f_[mu nu] components (up to factor two)."""
    rows = []
    for mu in range(n):
        for nu in range(mu + 1, n):
            row = np.zeros(n * n, dtype=float)
            row[vec_index(mu, nu, n)] = 1.0
            row[vec_index(nu, mu, n)] = -1.0
            rows.append(row)
    return np.vstack(rows)


def audit_pure_md_quadratic(n: int = 4, tol: float = 1e-12) -> GateResult:
    """Certify the already-derived limitation: e_mu wedge f^mu sees only f_[mu nu]."""
    a = antisymmetric_extractor(n)
    s = symmetric_embedding(n)
    residual = float(np.linalg.norm(a @ s))
    sym_dim = n * (n + 1) // 2
    return GateResult(
        gate="CS0",
        status=GateStatus.PASS if residual < tol else GateStatus.FAIL,
        statement=(
            "Pure Lorentz/D algebraic wedge terms annihilate the symmetric co-soldering subspace; "
            "they cannot by themselves give a Hessian to f_(mu nu)."
        ),
        residuals={
            "symmetric_dimension": sym_dim,
            "antisymmetric_dimension": n * (n - 1) // 2,
            "A_on_Sym_residual": residual,
        },
        witnesses=() if residual < tol else ("SYMMETRIC-PROJECTION-CONVENTION-MISMATCH",),
    )


def audit_symmetric_constraint_jacobian(
    jacobian_on_vec_f: Array | None,
    *,
    n: int = 4,
    tol: float = 1e-10,
) -> GateResult:
    """Project a full constraint Jacobian onto Sym^2 and ask whether all 10 modes are fixed.

    jacobian_on_vec_f has shape (number_of_constraints, n*n).
    """
    sym_dim = n * (n + 1) // 2
    if jacobian_on_vec_f is None:
        return GateResult(
            gate="CS1",
            status=GateStatus.OPEN,
            statement="Full D8/BRST constraint Jacobian on f_(mu nu) has not been supplied.",
            residuals={"symmetric_dimension": sym_dim},
            witnesses=("MISSING-COSOLDERING-CONSTRAINT-JACOBIAN",),
        )

    j = np.asarray(jacobian_on_vec_f, dtype=float)
    if j.ndim != 2 or j.shape[1] != n * n:
        raise ValueError(f"constraint Jacobian must have shape (m,{n*n})")
    s = symmetric_embedding(n)
    js = j @ s
    rank = matrix_rank(js, tol=tol)
    survivors = sym_dim - rank
    ns = nullspace(js, tol=tol)

    status = GateStatus.PASS if survivors == 0 else GateStatus.OPEN
    witnesses = () if survivors == 0 else ("SYMMETRIC-COSOLDERING-SURVIVORS",)
    return GateResult(
        gate="CS1",
        status=status,
        statement=(
            "Projected D8/BRST constraint rank on Sym^2(R^4). "
            "Rank 10 is the finite certificate that the ten symmetric f_(mu nu) components are removed."
        ),
        residuals={
            "constraint_rank_on_symmetric": rank,
            "symmetric_survivors": survivors,
        },
        witnesses=witnesses,
        details={"survivor_basis_columns": ns.tolist()},
    )
