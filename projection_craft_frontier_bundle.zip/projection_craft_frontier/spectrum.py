from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from .linear import intersection_null_with_gauge_complement
from .types import GateResult, GateStatus

Array = NDArray[np.float64]


def audit_constrained_quadratic_spectrum(
    hessian: Array | None,
    constraint_map: Array | None,
    gauge_map: Array | None,
    *,
    expected_physical_dimension: int | None = None,
    require_positive: bool = True,
    tol: float = 1e-9,
) -> GateResult:
    if hessian is None or constraint_map is None:
        return GateResult(
            gate="A5",
            status=GateStatus.OPEN,
            statement="Full constrained quadratic Hessian and/or constraint map has not been supplied.",
            witnesses=("MISSING-CONSTRAINED-HESSIAN-DATA",),
        )

    h = np.asarray(hessian, dtype=float)
    c = np.asarray(constraint_map, dtype=float)
    if h.ndim != 2 or h.shape[0] != h.shape[1]:
        raise ValueError("hessian must be square")
    if c.shape[1] != h.shape[0]:
        raise ValueError("constraint_map must act on the Hessian field space")

    reps = intersection_null_with_gauge_complement(c, gauge_map, tol=tol)
    hphys = reps.T @ (0.5 * (h + h.T)) @ reps
    eig = np.linalg.eigvalsh(hphys) if hphys.size else np.array([])
    negative = int(np.count_nonzero(eig < -tol))
    zero = int(np.count_nonzero(abs(eig) <= tol))
    positive = int(np.count_nonzero(eig > tol))
    dim = int(reps.shape[1])

    dimension_ok = expected_physical_dimension is None or dim == expected_physical_dimension
    sign_ok = (negative == 0 and zero == 0) if require_positive else True

    if expected_physical_dimension is None:
        status = GateStatus.CONDITIONAL
        witnesses = ("PHYSICAL-SPECTRUM-TARGET-NOT-DECLARED",)
    elif dimension_ok and sign_ok:
        status = GateStatus.PASS
        witnesses = ()
    else:
        status = GateStatus.OPEN
        witnesses = ("HEALTHY-SPECTRUM-NOT-CLOSED",)

    return GateResult(
        gate="A5",
        status=status,
        statement=(
            "Quadratic spectrum after imposing supplied constraints and removing supplied gauge directions. "
            "This is a finite Hessian test; identifying a surviving block as spin-2 still requires the sector map."
        ),
        residuals={
            "physical_representative_dimension": dim,
            "positive_eigenvalues": positive,
            "zero_eigenvalues": zero,
            "negative_eigenvalues": negative,
        },
        witnesses=witnesses,
        details={"physical_eigenvalues": eig.tolist()},
    )
