from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
from numpy.typing import NDArray

from .brst import audit_linear_complex
from .cosoldering import audit_pure_md_quadratic, audit_symmetric_constraint_jacobian
from .d8 import audit_d8_recurrence
from .matched_kernel import audit_matched_kernel
from .quasilinear import audit_reduced_quasilinear
from .radial import audit_radial_stationary_points
from .soldering import audit_coframe_rank
from .spectrum import audit_constrained_quadratic_spectrum
from .types import GateResult, GateStatus

Array = NDArray[np.float64]


@dataclass
class FrontierInputs:
    # Quasi-linear chart
    w: float = 0.0
    epsilon_p: int = 1

    # Positive-degree/radial activation
    g_phi_bb: float | None = None
    intersection_number: float | None = None
    v0_coefficients_ascending: Array | None = None

    # Matched-kernel full-adjoint test
    k_bf_full: Array | None = None
    m_bb_full: Array | None = None

    # Co-soldering f_(mu nu) test
    cosoldering_constraint_jacobian_on_vec_f: Array | None = None
    cosoldering_gauge_map_sym: Array | None = None
    cosoldering_constraint_map_sym: Array | None = None

    # Exterior rank
    candidate_coframe_4x4: Array | None = None

    # Full constrained spectrum
    full_constrained_hessian: Array | None = None
    full_constraint_map: Array | None = None
    full_gauge_map: Array | None = None
    expected_physical_dimension: int | None = None


def _open(name: str, statement: str, witness: str) -> GateResult:
    return GateResult(
        gate=name,
        status=GateStatus.OPEN,
        statement=statement,
        witnesses=(witness,),
    )


def run_frontier(inputs: FrontierInputs) -> list[GateResult]:
    """Evaluate the remaining Book-16 research gates in dependency order.

    A PASS means only the specific finite certificate named by that result.
    It does not auto-promote downstream physics.
    """
    out: list[GateResult] = []

    # Already-earned algebraic checks, encoded as regression tests.
    out.append(audit_reduced_quasilinear(inputs.w, inputs.epsilon_p))
    out.append(audit_d8_recurrence(inputs.w))
    out.append(audit_pure_md_quadratic())

    # A0: availability of the correct stabilizer is earned, dynamical selection is not.
    out.append(
        GateResult(
            gate="A0",
            status=GateStatus.OPEN,
            statement=(
                "The pair (T_w,D) has the desired residual Spin(10)xSpin(3,1) stabilizer "
                "at representation level, but the action has not yet selected/activated the orbit."
            ),
            witnesses=("LACKS-DYNAMICAL-LORENTZ-ORBIT-SELECTION",),
        )
    )

    # A1: positive-degree/radial branch.
    out.append(
        audit_radial_stationary_points(
            inputs.v0_coefficients_ascending,
            w=inputs.w,
            g_phi_bb=inputs.g_phi_bb,
            intersection_number=inputs.intersection_number,
        )
    )

    # Matched kernel: only test when actual full matrices are exported.
    if inputs.k_bf_full is None or inputs.m_bb_full is None:
        out.append(
            _open(
                "A2-MK",
                "Full-adjoint BF/BB matrices have not yet been exported for the matched-kernel test.",
                "MISSING-FULL-MATCHED-KERNEL-MATRICES",
            )
        )
    else:
        mk = audit_matched_kernel(inputs.k_bf_full, inputs.m_bb_full)
        out.append(
            GateResult(
                gate="A2-MK",
                status=mk.status,
                statement=mk.statement,
                residuals=mk.residuals,
                witnesses=mk.witnesses,
                details=mk.details,
            )
        )

    # Direct live question: do constraints actually remove Sym^2 f?
    cs = audit_symmetric_constraint_jacobian(
        inputs.cosoldering_constraint_jacobian_on_vec_f
    )
    out.append(cs)

    # BRST/cohomology restricted to the ten symmetric f components.
    if inputs.cosoldering_constraint_map_sym is None:
        out.append(
            _open(
                "A2-SYM-BRST",
                "No linearized BRST/constraint complex on the ten symmetric co-soldering components has been exported.",
                "MISSING-SYMMETRIC-BRST-COMPLEX",
            )
        )
    else:
        out.append(
            audit_linear_complex(
                inputs.cosoldering_gauge_map_sym,
                inputs.cosoldering_constraint_map_sym,
                field_dimension=10,
                target_physical_dimension=0,
                gate_name="A2-SYM-BRST",
            )
        )

    # A3: nondegenerate coframe.
    out.append(audit_coframe_rank(inputs.candidate_coframe_4x4))

    # A4 summary: the principal neutral line is structurally unique, but the symmetric f test is decisive.
    out.append(
        GateResult(
            gate="A4",
            status=GateStatus.PASS if cs.status == GateStatus.PASS else GateStatus.OPEN,
            statement=(
                "Neutral principal-symbol uniqueness is already certified by T_w. "
                "Action-level one-spin-2 closure additionally requires the symmetric co-soldering "
                "constraint/BRST test to leave no independent f_(mu nu) mode."
            ),
            residuals=cs.residuals,
            witnesses=cs.witnesses,
        )
    )

    # A5: full constrained quadratic spectrum.
    out.append(
        audit_constrained_quadratic_spectrum(
            inputs.full_constrained_hessian,
            inputs.full_constraint_map,
            inputs.full_gauge_map,
            expected_physical_dimension=inputs.expected_physical_dimension,
        )
    )

    # A6 remains downstream by construction.
    out.append(
        GateResult(
            gate="A6",
            status=GateStatus.OPEN,
            statement="Absolute mirror selection and physical cosmology remain downstream of A0-A5.",
            witnesses=("DOWNSTREAM-FIREWALL",),
        )
    )
    return out


def results_to_jsonable(results: list[GateResult]) -> dict[str, Any]:
    return {
        "frontier_results": [result.to_dict() for result in results],
        "all_passed": all(result.status == GateStatus.PASS for result in results),
    }
