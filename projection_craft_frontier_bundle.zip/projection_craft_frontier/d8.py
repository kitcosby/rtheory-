from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from .quasilinear import t_pk, t_u
from .types import GateResult, GateStatus

Array = NDArray[np.float64]


def wedge_one_forms(a: Array, b: Array) -> Array:
    """Antisymmetric coefficient matrix for a wedge b on a coordinate chart."""
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    if a.ndim != 1 or b.ndim != 1 or a.shape != b.shape:
        raise ValueError("a and b must be same-length one-form coefficient vectors")
    return np.outer(a, b) - np.outer(b, a)


def j_d(alpha: Array, beta: Array) -> Array:
    """J_D=sum_i alpha_i wedge beta_i.

    alpha,beta shape: (10, base_dimension) for the ten reciprocal mixed pairs.
    """
    alpha = np.asarray(alpha, dtype=float)
    beta = np.asarray(beta, dtype=float)
    if alpha.shape != beta.shape or alpha.ndim != 2:
        raise ValueError("alpha and beta must have the same shape (10, base_dimension)")
    if alpha.shape[0] != 10:
        raise ValueError("the Book-16 D8 mixed sector has ten reciprocal pairs")
    out = np.zeros((alpha.shape[1], alpha.shape[1]), dtype=float)
    for i in range(10):
        out += wedge_one_forms(alpha[i], beta[i])
    return out


def audit_d8_recurrence(w: float = 0.731, tol: float = 1e-12) -> GateResult:
    residual = float(np.linalg.norm(t_u(w) - t_pk(w) - 0.25 * np.eye(2)))
    eig = np.linalg.eigvals(t_u(w))
    target = np.array([0.25, 1.25])
    eig_res = float(np.linalg.norm(np.sort(eig.real) - target))
    passed = residual < tol and eig_res < tol
    return GateResult(
        gate="D8",
        status=GateStatus.PASS if passed else GateStatus.FAIL,
        statement=(
            "Each mixed D8 pair carries the same rapidity transport as P/K, shifted by one quarter; "
            "these are the reciprocal pairs whose opposite grades source the D curvature."
        ),
        residuals={"quarter_shift": residual, "eigenvalue_residual": eig_res},
        witnesses=() if passed else ("D8-RECURRENCE-FAIL",),
    )
