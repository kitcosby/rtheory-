from __future__ import annotations

from pathlib import Path
from typing import Mapping

import numpy as np


FRONTIER_EXPORT_KEYS = (
    "cosoldering_constraint_jacobian_on_vec_f",
    "cosoldering_gauge_map_sym",
    "cosoldering_constraint_map_sym",
    "candidate_coframe_4x4",
    "k_bf_full",
    "m_bb_full",
    "full_constrained_hessian",
    "full_constraint_map",
    "full_gauge_map",
)


def frontier_arrays_from_pipeline(namespace: Mapping[str, object]) -> dict[str, np.ndarray]:
    """Collect only frontier arrays that the certified pipeline actually computed.

    This function intentionally does not fabricate missing arrays.  Call it at
    the end of projection_craft_full_pipeline.py after the exact E8/PCBF
    calculation has populated its namespace/result object.
    """
    out: dict[str, np.ndarray] = {}
    for key in FRONTIER_EXPORT_KEYS:
        value = namespace.get(key)
        if value is not None:
            out[key] = np.asarray(value)
    return out


def save_frontier_npz(path: str | Path, **arrays: object) -> None:
    """Write a frontier-only NPZ without changing the existing microscopic NPZ."""
    clean = {
        key: np.asarray(value)
        for key, value in arrays.items()
        if key in FRONTIER_EXPORT_KEYS and value is not None
    }
    np.savez_compressed(path, **clean)
