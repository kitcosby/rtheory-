import numpy as np

from projection_craft_frontier.d8_cosoldering import (
    audit_d8_cosoldering_visibility,
    d8_cosoldering_rank,
)
from projection_craft_frontier.types import GateStatus


def test_rank_zero_background_sees_nothing():
    d = d8_cosoldering_rank(np.zeros((10,4)))
    assert d["symmetric_rank"] == 0
    assert d["symmetric_survivors"] == 10


def test_rank_one_background_is_insufficient():
    gamma = np.tile(np.array([[1.,0.,0.,0.]]), (10,1))
    d = d8_cosoldering_rank(gamma)
    assert d["background_one_form_span_rank"] == 1
    assert d["symmetric_rank"] < 10
    result = audit_d8_cosoldering_visibility(gamma)
    assert result.status == GateStatus.FAIL


def test_two_independent_mixed_one_forms_see_all_symmetric_modes():
    gamma = np.vstack([
        np.array([[1.,0.,0.,0.]]),
        np.array([[0.,1.,0.,0.]]),
        np.zeros((8,4)),
    ])
    d = d8_cosoldering_rank(gamma)
    assert d["background_one_form_span_rank"] == 2
    assert d["symmetric_rank"] == 10
    assert d["symmetric_survivors"] == 0
    result = audit_d8_cosoldering_visibility(gamma)
    assert result.status == GateStatus.CONDITIONAL
