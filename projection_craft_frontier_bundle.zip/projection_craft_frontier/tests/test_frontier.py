import numpy as np

from projection_craft_frontier.brst import audit_linear_complex
from projection_craft_frontier.cosoldering import (
    antisymmetric_extractor,
    audit_pure_md_quadratic,
    audit_symmetric_constraint_jacobian,
    symmetric_embedding,
)
from projection_craft_frontier.d8 import audit_d8_recurrence
from projection_craft_frontier.matched_kernel import audit_matched_kernel
from projection_craft_frontier.quasilinear import (
    audit_reduced_quasilinear,
    khat_pk,
    p_cf,
)
from projection_craft_frontier.types import GateStatus


def test_quasilinear_regressions():
    for w in (-2.0, -0.7, 0.0, 0.8, 2.1):
        assert audit_reduced_quasilinear(w).status == GateStatus.PASS
        p = p_cf(w)
        assert np.linalg.norm(p @ p - p) < 1e-12
        assert abs(np.linalg.det(khat_pk(w))) < 1e-12


def test_d8_recurrence():
    assert audit_d8_recurrence(0.91).status == GateStatus.PASS


def test_pure_md_cannot_see_symmetric_f():
    result = audit_pure_md_quadratic()
    assert result.status == GateStatus.PASS
    assert result.residuals["symmetric_dimension"] == 10
    assert result.residuals["A_on_Sym_residual"] == 0.0


def test_full_rank_symmetric_constraint_closes_gate():
    s = symmetric_embedding()
    # A left inverse on the symmetric subspace gives ten independent constraints.
    j = np.linalg.pinv(s)
    result = audit_symmetric_constraint_jacobian(j)
    assert result.status == GateStatus.PASS
    assert result.residuals["constraint_rank_on_symmetric"] == 10


def test_six_antisymmetric_constraints_leave_all_ten_symmetric_modes():
    a = antisymmetric_extractor()
    result = audit_symmetric_constraint_jacobian(a)
    assert result.status == GateStatus.OPEN
    assert result.residuals["symmetric_survivors"] == 10


def test_brst_toy_removes_all_symmetric_modes():
    c = np.eye(10)
    result = audit_linear_complex(
        gauge_map=None,
        constraint_map=c,
        field_dimension=10,
        target_physical_dimension=0,
        gate_name="toy",
    )
    assert result.status == GateStatus.PASS


def test_matched_kernel():
    k = np.diag([1.0, 2.0, 0.0])
    m = np.diag([3.0, 4.0, 0.0])
    result = audit_matched_kernel(k, m)
    assert result.status == GateStatus.PASS
    assert result.residuals["nullity_K"] == 1
