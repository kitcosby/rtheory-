import numpy as np

from projection_craft_frontier.d8_background import (
    audit_jd_vs_cosoldering_visibility,
    audit_zero_mixed_background_symmetric_count,
)


def test_jd_nonzero_does_not_imply_full_symmetric_visibility():
    gamma = np.zeros((10,4))
    delta = np.zeros((10,4))
    gamma[0] = [1,0,0,0]
    delta[0] = [0,1,0,0]
    alpha = (gamma + delta)/np.sqrt(2)
    beta = (gamma - delta)/np.sqrt(2)
    r = audit_jd_vs_cosoldering_visibility(alpha, beta)
    assert r.residuals["JD_norm"] > 0
    assert r.residuals["gamma_span_rank"] == 1
    assert r.residuals["symmetric_visibility_rank"] == 9
    assert r.residuals["symmetric_survivors"] == 1


def test_generic_y_gauge_removes_only_four_of_ten_symmetric_components():
    r = audit_zero_mixed_background_symmetric_count(
        np.array([1.0, 0.7, -0.4, 0.9])
    )
    assert r.residuals["Y_gauge_rank_on_Sym2"] == 4
    assert r.residuals["gauge_inequivalent_symmetric_dimension"] == 6
