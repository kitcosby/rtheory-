from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
from numpy.typing import NDArray

Array = NDArray[np.float64]


@dataclass
class ExistingPipelineData:
    """Optional arrays imported from the existing Projection Craft pipeline.

    The adapter deliberately does not reconstruct E8 roots or change conventions.
    It only reads arrays already emitted by the certified derivation code.
    """
    arrays: dict[str, Array]

    @classmethod
    def from_npz(cls, path: str | Path) -> "ExistingPipelineData":
        with np.load(path, allow_pickle=False) as data:
            arrays = {name: np.asarray(data[name]) for name in data.files}
        return cls(arrays=arrays)

    def get(self, name: str, default: Any = None):
        return self.arrays.get(name, default)

    def require(self, name: str) -> Array:
        if name not in self.arrays:
            raise KeyError(
                f"Required array {name!r} missing. "
                "Do not synthesize it here; export it from the certified E8/PCBF pipeline."
            )
        return self.arrays[name]


# Suggested new export keys. The existing engine may use different names;
# map them once in projection_craft_full_pipeline.py rather than changing
# the algebraic routines.
SUGGESTED_FRONTIER_KEYS = (
    "cosoldering_constraint_jacobian_on_vec_f",   # shape (m,16)
    "cosoldering_gauge_map_sym",                  # shape (10,g), optional
    "cosoldering_constraint_map_sym",             # shape (c,10), optional
    "candidate_coframe_4x4",                      # shape (4,4)
    "full_constrained_hessian",                   # shape (N,N)
    "full_constraint_map",                        # shape (c,N)
    "full_gauge_map",                             # shape (N,g)
    "k_bf_full",                                  # matched-kernel diagnostic
    "m_bb_full",
)
