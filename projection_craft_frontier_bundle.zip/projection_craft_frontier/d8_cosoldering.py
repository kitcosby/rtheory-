from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from .cosoldering import symmetric_embedding
from .linear import matrix_rank, nullspace
from .types import GateResult, GateStatus

Array = NDArray[np.float64]


def two_form_pairs(n: int = 4) -> list[tuple[int, int]]:
    return [(a, b) for a in range(n) for b in range(a + 1, n)]


def wedge_with_background_map(gamma: Array, n: int = 4) -> Array:
    """Map vec(f^mu_nu) -> stacked components of f^mu wedge gamma_i.

    gamma shape: (n_mixed, n), one background one-form gamma_i for each
    internal mixed pair that couples Y_mu into W_{i mu} via the exact
    orthogonal-algebra bracket [Y_mu,U_i^a] ~ W_{i mu}.
    """
    gamma = np.asarray(gamma, dtype=float)
    if gamma.ndim != 2 or gamma.shape[1] != n:
        raise ValueError(f"gamma must have shape (n_mixed,{n})")

    pairs = two_form_pairs(n)
    rows = []
    for i in range(gamma.shape[0]):
        g = gamma[i]
        for mu in range(n):
            for rho, sigma in pairs:
                row = np.zeros(n * n, dtype=float)
                row[mu * n + rho] += g[sigma]
                row[mu * n + sigma] -= g[rho]
                rows.append(row)
    return np.vstack(rows) if rows else np.zeros((0, n * n))


def d8_cosoldering_rank(gamma: Array, n: int = 4, tol: float = 1e-10) -> dict:
    """Necessary-condition rank test for D8 curvature sensitivity."""
    gamma = np.asarray(gamma, dtype=float)
    j = wedge_with_background_map(gamma, n=n)
    s = symmetric_embedding(n)
    js = j @ s

    r_gamma = matrix_rank(gamma, tol=tol)
    r_full = matrix_rank(j, tol=tol)
    r_sym = matrix_rank(js, tol=tol)
    sym_dim = n * (n + 1) // 2
    ns = nullspace(js, tol=tol)
    return {
        "background_one_form_span_rank": r_gamma,
        "full_f_rank": r_full,
        "symmetric_rank": r_sym,
        "symmetric_survivors": sym_dim - r_sym,
        "symmetric_survivor_basis_columns": ns,
    }


def audit_d8_cosoldering_visibility(
    gamma: Array | None,
    n: int = 4,
    tol: float = 1e-10,
) -> GateResult:
    """Can the active D8 mixed background see all symmetric co-soldering modes?

    This is a NECESSARY visibility test, not a full EOM/BRST sufficiency test.
    """
    sym_dim = n * (n + 1) // 2
    if gamma is None:
        return GateResult(
            gate="D8-CS-VIS",
            status=GateStatus.OPEN,
            statement=(
                "No D8 mixed background one-forms have been supplied. "
                "Visibility of f_(mu nu) cannot be tested."
            ),
            residuals={"symmetric_dimension": sym_dim},
            witnesses=("MISSING-D8-MIXED-BACKGROUND",),
        )

    d = d8_cosoldering_rank(gamma, n=n, tol=tol)
    r_sym = d["symmetric_rank"]
    survivors = d["symmetric_survivors"]

    if r_sym == sym_dim:
        status = GateStatus.CONDITIONAL
        statement = (
            "The exact D8 curvature-sensitivity map can see all ten symmetric "
            "co-soldering components on this background. This removes the algebraic "
            "visibility obstruction, but the full PCBF EOM/BRST Jacobian must still "
            "show that these visible directions are actually constrained or lifted."
        )
        witnesses = ("NEEDS-FULL-PCBF-EOM-BRST-JACOBIAN",)
    else:
        status = GateStatus.FAIL
        statement = (
            "This D8 background cannot see all ten symmetric co-soldering components; "
            "additional couplings or a higher-rank mixed background are required."
        )
        witnesses = ("D8-BACKGROUND-RANK-INSUFFICIENT",)

    return GateResult(
        gate="D8-CS-VIS",
        status=status,
        statement=statement,
        residuals={
            "background_one_form_span_rank": d["background_one_form_span_rank"],
            "full_f_rank": d["full_f_rank"],
            "symmetric_rank": r_sym,
            "symmetric_survivors": survivors,
        },
        witnesses=witnesses,
        details={
            "symmetric_survivor_basis_columns":
                d["symmetric_survivor_basis_columns"].tolist()
        },
    )
