from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from .linear import matrix_rank, nullspace, orth
from .types import GateResult, GateStatus

Array = NDArray[np.float64]


def _projector_from_basis(q: Array) -> Array:
    if q.size == 0:
        return np.zeros((q.shape[0], q.shape[0]), dtype=float)
    return q @ q.T


def audit_matched_kernel(
    k: Array,
    m: Array,
    *,
    tol: float = 1e-10,
) -> GateResult:
    """Check the singular matched-kernel escape without inverting M."""
    k = np.asarray(k, dtype=float)
    m = np.asarray(m, dtype=float)
    if k.ndim != 2 or m.ndim != 2 or k.shape != m.shape or k.shape[0] != k.shape[1]:
        raise ValueError("K and M must be same-size square matrices")

    nk = nullspace(k, tol=tol)
    nm = nullspace(m, tol=tol)
    pk = _projector_from_basis(nk)
    pm = _projector_from_basis(nm)
    kernel_residual = float(np.linalg.norm(pk - pm))

    rank_k = matrix_rank(k, tol=tol)
    rank_m = matrix_rank(m, tol=tol)
    matched = kernel_residual < 100 * tol and nk.shape[1] == nm.shape[1]

    return GateResult(
        gate="MK",
        status=GateStatus.PASS if matched else GateStatus.FAIL,
        statement=(
            "BF and BB kernels share the same singular null bundle, so auxiliary elimination is performed "
            "on the image and no inverse of the full heavy kernel is required."
        ),
        residuals={
            "rank_K": rank_k,
            "rank_M": rank_m,
            "nullity_K": int(nk.shape[1]),
            "nullity_M": int(nm.shape[1]),
            "kernel_projector_residual": kernel_residual,
        },
        witnesses=() if matched else ("BF-BB-KERNEL-MISMATCH",),
    )


def effective_image_hessian(k: Array, m: Array, tol: float = 1e-10) -> Array:
    """Schur complement on the non-null image only, using the Moore-Penrose inverse.

    This is diagnostic. It is lawful for the matched-kernel branch because the
    null auxiliary directions are gauge/redundant rather than Gaussian fields.
    """
    k = np.asarray(k, dtype=float)
    m = np.asarray(m, dtype=float)
    return k.T @ np.linalg.pinv(m, rcond=tol) @ k
