from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from .linear import intersection_null_with_gauge_complement, matrix_rank
from .types import GateResult, GateStatus

Array = NDArray[np.float64]


def audit_linear_complex(
    gauge_map: Array | None,
    constraint_map: Array | None,
    *,
    field_dimension: int,
    target_physical_dimension: int | None = None,
    tol: float = 1e-10,
    gate_name: str = "BRST",
) -> GateResult:
    """Finite-dimensional ghost-number-zero diagnostic.

    gauge_map: fields <- gauge parameters, shape (field_dimension, n_gauge)
    constraint_map: equations <- fields, shape (n_constraints, field_dimension)

    The composability residual C G must vanish. Physical representatives are
    ker(C) intersect im(G)^perp, a gauge-fixed representative of H^0.
    """
    if constraint_map is None:
        return GateResult(
            gate=gate_name,
            status=GateStatus.OPEN,
            statement="Linearized constraint/BRST map has not been supplied.",
            residuals={"field_dimension": field_dimension},
            witnesses=("MISSING-BRST-CONSTRAINT-MAP",),
        )

    c = np.asarray(constraint_map, dtype=float)
    if c.shape[1] != field_dimension:
        raise ValueError("constraint_map column count must equal field_dimension")

    g = None if gauge_map is None else np.asarray(gauge_map, dtype=float)
    if g is not None and g.shape[0] != field_dimension:
        raise ValueError("gauge_map row count must equal field_dimension")

    closure = 0.0 if g is None or g.size == 0 else float(np.linalg.norm(c @ g))
    reps = intersection_null_with_gauge_complement(c, g, tol=tol)
    h0_dim = int(reps.shape[1])

    if closure > 100 * tol:
        status = GateStatus.FAIL
        witnesses = ("LINEAR-COMPLEX-DOES-NOT-CLOSE",)
    elif target_physical_dimension is None:
        status = GateStatus.CONDITIONAL
        witnesses = ("PHYSICAL-DIMENSION-TARGET-NOT-DECLARED",)
    elif h0_dim == target_physical_dimension:
        status = GateStatus.PASS
        witnesses = ()
    else:
        status = GateStatus.OPEN
        witnesses = ("UNRESOLVED-GHOST-NUMBER-ZERO-CLASSES",)

    return GateResult(
        gate=gate_name,
        status=status,
        statement="Linearized BRST/constraint cohomology diagnostic at ghost number zero.",
        residuals={
            "closure_residual_CG": closure,
            "rank_constraint": matrix_rank(c, tol=tol),
            "rank_gauge": 0 if g is None else matrix_rank(g, tol=tol),
            "H0_representative_dimension": h0_dim,
            "target_physical_dimension": -1 if target_physical_dimension is None else target_physical_dimension,
        },
        witnesses=witnesses,
        details={"H0_representative_basis_columns": reps.tolist()},
    )
