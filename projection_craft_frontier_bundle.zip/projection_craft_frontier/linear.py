from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

Array = NDArray[np.float64]


def matrix_rank(a: Array, tol: float = 1e-10) -> int:
    if a.size == 0:
        return 0
    s = np.linalg.svd(a, compute_uv=False)
    if s.size == 0:
        return 0
    threshold = tol * max(a.shape) * max(float(s[0]), 1.0)
    return int(np.count_nonzero(s > threshold))


def nullspace(a: Array, tol: float = 1e-10) -> Array:
    """Columns form an orthonormal basis for ker(a)."""
    a = np.asarray(a, dtype=float)
    if a.ndim != 2:
        raise ValueError("nullspace expects a matrix")
    if a.shape[1] == 0:
        return np.zeros((0, 0), dtype=float)
    u, s, vh = np.linalg.svd(a, full_matrices=True)
    if s.size:
        threshold = tol * max(a.shape) * max(float(s[0]), 1.0)
        rank = int(np.count_nonzero(s > threshold))
    else:
        rank = 0
    return vh[rank:].T.copy()


def orth(a: Array, tol: float = 1e-10) -> Array:
    """Columns form an orthonormal basis for im(a)."""
    a = np.asarray(a, dtype=float)
    if a.ndim != 2:
        raise ValueError("orth expects a matrix")
    if a.size == 0:
        return np.zeros((a.shape[0], 0), dtype=float)
    u, s, _ = np.linalg.svd(a, full_matrices=False)
    if s.size:
        threshold = tol * max(a.shape) * max(float(s[0]), 1.0)
        rank = int(np.count_nonzero(s > threshold))
    else:
        rank = 0
    return u[:, :rank].copy()


def intersection_null_with_gauge_complement(
    constraint_map: Array,
    gauge_map: Array | None,
    tol: float = 1e-10,
) -> Array:
    """Physical linear representatives: ker(C) intersect im(G)^perp.

    This is a finite-dimensional gauge-fixed representative of
        ker(C) / im(G)
    when C @ G = 0.
    """
    c = np.asarray(constraint_map, dtype=float)
    n = c.shape[1]
    if gauge_map is None or np.asarray(gauge_map).size == 0:
        return nullspace(c, tol=tol)

    g = np.asarray(gauge_map, dtype=float)
    if g.shape[0] != n:
        raise ValueError("gauge_map must have one row per field component")
    qg = orth(g, tol=tol)
    stacked = np.vstack([c, qg.T])
    return nullspace(stacked, tol=tol)
