from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from .d8 import j_d
from .d8_cosoldering import d8_cosoldering_rank
from .linear import matrix_rank
from .types import GateResult, GateStatus

Array = NDArray[np.float64]


def null_pair_to_normal_components(alpha: Array, beta: Array) -> tuple[Array, Array]:
    """Convert reciprocal null-grade one-forms to a/b normal components.

    With n_±=(a±b)/sqrt(2),
        alpha U^+ + beta U^-
      = gamma U^a + delta U^b,
    gamma=(alpha+beta)/sqrt(2),
    delta=(alpha-beta)/sqrt(2).

    Overall normalization does not affect visibility ranks.
    """
    alpha = np.asarray(alpha, dtype=float)
    beta = np.asarray(beta, dtype=float)
    if alpha.shape != beta.shape:
        raise ValueError("alpha and beta must have the same shape")
    root2 = np.sqrt(2.0)
    return (alpha + beta) / root2, (alpha - beta) / root2


def jd_from_normal_components(gamma: Array, delta: Array) -> Array:
    """Equivalent D-curvature source, up to the fixed bracket normalization.

    Sum alpha_i wedge beta_i = - sum gamma_i wedge delta_i.
    """
    gamma = np.asarray(gamma, dtype=float)
    delta = np.asarray(delta, dtype=float)
    if gamma.shape != delta.shape:
        raise ValueError("gamma and delta must have the same shape")
    out = np.zeros((gamma.shape[1], gamma.shape[1]), dtype=float)
    for i in range(gamma.shape[0]):
        out -= np.outer(gamma[i], delta[i]) - np.outer(delta[i], gamma[i])
    return out


def audit_jd_vs_cosoldering_visibility(
    alpha: Array,
    beta: Array,
    tol: float = 1e-10,
) -> GateResult:
    alpha = np.asarray(alpha, dtype=float)
    beta = np.asarray(beta, dtype=float)
    gamma, delta = null_pair_to_normal_components(alpha, beta)

    jd1 = j_d(alpha, beta)
    jd2 = jd_from_normal_components(gamma, delta)
    conversion_residual = float(np.linalg.norm(jd1 - jd2))

    vis = d8_cosoldering_rank(gamma, tol=tol)
    jd_rank = matrix_rank(jd1, tol=tol)
    jd_norm = float(np.linalg.norm(jd1))

    if jd_norm > tol and vis["symmetric_rank"] < 10:
        status = GateStatus.FAIL
        statement = (
            "Nonzero D8 topological source J_D does not by itself imply sufficient "
            "mixed-background rank to see all symmetric co-soldering modes."
        )
        witnesses = ("JD-NONZERO-BUT-COSOLDERING-VISIBILITY-INCOMPLETE",)
    elif jd_norm > tol and vis["symmetric_rank"] == 10:
        status = GateStatus.CONDITIONAL
        statement = (
            "This configuration has both nonzero J_D and full symmetric visibility. "
            "The full PCBF EOM/BRST Jacobian is still required for actual lifting."
        )
        witnesses = ("NEEDS-FULL-PCBF-EOM-BRST-JACOBIAN",)
    else:
        status = GateStatus.OPEN
        statement = "J_D vanishes on this supplied configuration."
        witnesses = ("JD-ZERO",)

    return GateResult(
        gate="D8-JD-CS",
        status=status,
        statement=statement,
        residuals={
            "JD_norm": jd_norm,
            "JD_rank_as_two_form_matrix": jd_rank,
            "gamma_span_rank": vis["background_one_form_span_rank"],
            "symmetric_visibility_rank": vis["symmetric_rank"],
            "symmetric_survivors": vis["symmetric_survivors"],
            "null_to_normal_conversion_residual": conversion_residual,
        },
        witnesses=witnesses,
    )


def symmetric_y_gauge_map(momentum: Array, n: int = 4) -> Array:
    """Principal Y-gauge map zeta_mu -> delta f_(mu nu)=k_(mu zeta_nu).

    Returns a 10 x 4 map in the canonical symmetric-component basis.
    """
    k = np.asarray(momentum, dtype=float)
    if k.shape != (n,):
        raise ValueError(f"momentum must have shape ({n},)")
    pairs = [(mu, nu) for mu in range(n) for nu in range(mu, n)]
    g = np.zeros((len(pairs), n), dtype=float)
    for row, (mu, nu) in enumerate(pairs):
        if mu == nu:
            g[row, mu] = k[mu]
        else:
            g[row, nu] += 0.5 * k[mu]
            g[row, mu] += 0.5 * k[nu]
    return g


def audit_zero_mixed_background_symmetric_count(
    momentum: Array,
    tol: float = 1e-10,
) -> GateResult:
    """Gauge count if no classical mixed background supplies symmetric constraints."""
    g = symmetric_y_gauge_map(momentum)
    rg = matrix_rank(g, tol=tol)
    remaining = 10 - rg
    return GateResult(
        gate="SYM-ZERO-MIXED",
        status=GateStatus.FAIL if remaining > 0 else GateStatus.PASS,
        statement=(
            "At zero classical mixed background, the known Lorentz/D algebraic terms "
            "supply no symmetric f constraint. The Y-sector gauge map removes only its "
            "principal gauge image; the remainder is a quadratic strong-coupling warning."
        ),
        residuals={
            "Y_gauge_rank_on_Sym2": rg,
            "gauge_inequivalent_symmetric_dimension": remaining,
        },
        witnesses=(
            ("SYMMETRIC-QUADRATIC-FLAT-DIRECTIONS",) if remaining > 0 else ()
        ),
    )
