from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from .types import GateResult, GateStatus

Array = NDArray[np.float64]

KNOWN_T_SPECTRUM = {
    0.0: 4,
    0.25: 11,
    0.75: 6,
    1.0: 172,
    1.25: 55,
}


def p_cf(w: float, epsilon_p: int = 1) -> Array:
    q = np.tanh(w)
    s = 1.0 / np.cosh(w)
    return 0.5 * np.array(
        [[1.0 + q, epsilon_p * s], [epsilon_p * s, 1.0 - q]],
        dtype=float,
    )


def khat_pk(w: float, epsilon_p: int = 1) -> Array:
    """Covariant quasi-linear P/K carrier, Khat=(1/S) P_cf."""
    return 0.5 * np.array(
        [[np.exp(w), float(epsilon_p)],
         [float(epsilon_p), np.exp(-w)]],
        dtype=float,
    )


def t_pk(w: float, epsilon_p: int = 1) -> Array:
    """Killing-raised P/K endomorphism block."""
    return 0.5 * np.array(
        [[1.0, epsilon_p * np.exp(-w)],
         [epsilon_p * np.exp(w), 1.0]],
        dtype=float,
    )


def t_u(w: float, epsilon_p: int = 1) -> Array:
    """One D8 mixed pair. Exact recurrence T_U=T_PK+I/4."""
    return np.array(
        [[0.75, 0.5 * epsilon_p * np.exp(-w)],
         [0.5 * epsilon_p * np.exp(w), 0.75]],
        dtype=float,
    )


def kernel_vector_pk(w: float, epsilon_p: int = 1) -> Array:
    return np.array([np.exp(-w / 2.0), -epsilon_p * np.exp(w / 2.0)])


def retained_vector_pk(w: float, epsilon_p: int = 1) -> Array:
    return np.array([np.exp(-w / 2.0), epsilon_p * np.exp(w / 2.0)])


def spectral_kernel_projector(t: Array) -> Array:
    """Pi_0(T)=((T-I)(4T-5I)(4T-3I)(4T-I))/15."""
    t = np.asarray(t, dtype=float)
    eye = np.eye(t.shape[0])
    return (
        (t - eye)
        @ (4.0 * t - 5.0 * eye)
        @ (4.0 * t - 3.0 * eye)
        @ (4.0 * t - eye)
        / 15.0
    )


def audit_reduced_quasilinear(w: float = 0.731, epsilon_p: int = 1, tol: float = 1e-11) -> GateResult:
    p = p_cf(w, epsilon_p)
    kh = khat_pk(w, epsilon_p)
    tp = t_pk(w, epsilon_p)
    tu = t_u(w, epsilon_p)
    s = 1.0 / np.cosh(w)
    n = kernel_vector_pk(w, epsilon_p)

    residuals = {
        "P_idempotency": float(np.linalg.norm(p @ p - p)),
        "Khat_det": float(abs(np.linalg.det(kh))),
        "Khat_minus_P_over_S": float(np.linalg.norm(kh - p / s)),
        "D8_quarter_shift": float(np.linalg.norm(tu - tp - 0.25 * np.eye(2))),
        "kernel_residual": float(np.linalg.norm(kh @ n)),
        "spectrum_multiplicity_sum": int(sum(KNOWN_T_SPECTRUM.values())),
        "spectrum_trace": float(sum(ev * mult for ev, mult in KNOWN_T_SPECTRUM.items())),
    }
    passed = (
        residuals["P_idempotency"] < tol
        and residuals["Khat_det"] < tol
        and residuals["Khat_minus_P_over_S"] < tol
        and residuals["D8_quarter_shift"] < tol
        and residuals["kernel_residual"] < tol
        and residuals["spectrum_multiplicity_sum"] == 248
        and abs(residuals["spectrum_trace"] - 248.0) < tol
    )
    return GateResult(
        gate="QL",
        status=GateStatus.PASS if passed else GateStatus.FAIL,
        statement=(
            "Quasi-linear transported carrier retains the exact rank-one P/K line, "
            "the quarter-shift D8 recurrence, and the certified full-E8 spectrum ledger."
        ),
        residuals=residuals,
        witnesses=() if passed else ("QUASILINEAR-CERTIFICATION-RESIDUAL",),
    )
