from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any


class GateStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    OPEN = "OPEN"
    CONDITIONAL = "CONDITIONAL"
    UNDERDETERMINED = "UNDERDETERMINED"


@dataclass(frozen=True)
class GateResult:
    gate: str
    status: GateStatus
    statement: str
    residuals: dict[str, float | int | str] = field(default_factory=dict)
    witnesses: tuple[str, ...] = ()
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        out = asdict(self)
        out["status"] = self.status.value
        return out
