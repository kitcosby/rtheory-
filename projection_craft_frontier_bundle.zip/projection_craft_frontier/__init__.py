"""Projection Craft Book-16 frontier research harness.

This package does not add physics. It turns the remaining manuscript gates into
explicit, independently testable calculations with failure witnesses.
"""

from .types import GateResult, GateStatus
from .gates import FrontierInputs, run_frontier

__all__ = ["GateResult", "GateStatus", "FrontierInputs", "run_frontier"]
