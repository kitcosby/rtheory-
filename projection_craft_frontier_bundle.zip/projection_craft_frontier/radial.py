from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from .types import GateResult, GateStatus

Array = NDArray[np.float64]


def polynomial_derivative(coefficients_ascending: Array, order: int = 1) -> Array:
    c = np.asarray(coefficients_ascending, dtype=float)
    for _ in range(order):
        if len(c) <= 1:
            return np.array([0.0])
        c = np.array([i * c[i] for i in range(1, len(c))], dtype=float)
    return c


def polyval_ascending(coefficients_ascending: Array, x: float) -> float:
    return float(sum(c * x**i for i, c in enumerate(coefficients_ascending)))


def audit_radial_stationary_points(
    v0_coefficients_ascending: Array | None,
    *,
    w: float,
    g_phi_bb: float | None,
    intersection_number: float | None,
    tol: float = 1e-9,
) -> GateResult:
    """Solve V0'(mu)=(12/7) g n cosh(2w) for positive real mu.

    V0 coefficients are [c0,c1,...] for V0(mu)=sum c_i mu^i.
    """
    if g_phi_bb is None:
        return GateResult(
            gate="A1-RAD",
            status=GateStatus.OPEN,
            statement="The representation-admissible PhiBB invariant exists, but its microscopic coupling is not derived.",
            witnesses=("MISSING-g_PhiBB",),
        )
    if intersection_number is None:
        return GateResult(
            gate="A1-RAD",
            status=GateStatus.OPEN,
            statement="No nontrivial global intersection/topological sector has been supplied.",
            witnesses=("MISSING-TOPOLOGICAL-INTERSECTION-DATA",),
        )
    if v0_coefficients_ascending is None:
        return GateResult(
            gate="A1-RAD",
            status=GateStatus.OPEN,
            statement="No radial stabilizer V0(mu) has been supplied.",
            witnesses=("MISSING-RADIAL-STABILIZER",),
        )

    c = np.asarray(v0_coefficients_ascending, dtype=float)
    d1 = polynomial_derivative(c, 1)
    rhs = (12.0 / 7.0) * g_phi_bb * intersection_number * np.cosh(2.0 * w)
    eq = d1.copy()
    if eq.size == 0:
        eq = np.array([-rhs])
    else:
        eq[0] -= rhs

    # np.roots wants descending order.
    roots = np.roots(eq[::-1]) if len(eq) > 1 else np.array([], dtype=complex)
    positive = sorted(
        float(r.real)
        for r in roots
        if abs(r.imag) < tol and r.real > tol
    )
    d2 = polynomial_derivative(c, 2)
    stable = [mu for mu in positive if polyval_ascending(d2, mu) > tol]

    status = GateStatus.PASS if stable else GateStatus.OPEN
    witnesses = () if stable else ("NO-STABLE-POSITIVE-RADIAL-ROOT",)
    return GateResult(
        gate="A1-RAD",
        status=status,
        statement="Finite-radius selection test on the exact N_3875(D)=-(12/7) mu cosh(2w) branch.",
        residuals={
            "rhs": float(rhs),
            "positive_stationary_count": len(positive),
            "stable_positive_count": len(stable),
        },
        witnesses=witnesses,
        details={"positive_stationary_mu": positive, "stable_positive_mu": stable},
    )
