from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from .adapters import ExistingPipelineData
from .gates import FrontierInputs, results_to_jsonable, run_frontier


def scalar_from_json(config: dict, name: str, default=None):
    return config[name] if name in config else default


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run modular Projection Craft Book-16 frontier gates."
    )
    parser.add_argument("--npz", type=Path, help="Optional existing pipeline NPZ")
    parser.add_argument("--config", type=Path, help="Optional JSON scalars/config")
    parser.add_argument("--out", type=Path, default=Path("projection_craft_frontier_report.json"))
    args = parser.parse_args()

    config = {}
    if args.config:
        config = json.loads(args.config.read_text())

    data = ExistingPipelineData.from_npz(args.npz) if args.npz else None
    get = (lambda key: None if data is None else data.get(key))

    inputs = FrontierInputs(
        w=float(scalar_from_json(config, "w", 0.0)),
        epsilon_p=int(scalar_from_json(config, "epsilon_p", 1)),
        g_phi_bb=scalar_from_json(config, "g_phi_bb"),
        intersection_number=scalar_from_json(config, "intersection_number"),
        v0_coefficients_ascending=(
            None
            if "v0_coefficients_ascending" not in config
            else np.asarray(config["v0_coefficients_ascending"], dtype=float)
        ),
        k_bf_full=get("k_bf_full"),
        m_bb_full=get("m_bb_full"),
        d8_mixed_background_gamma=get("d8_mixed_background_gamma"),
        cosoldering_constraint_jacobian_on_vec_f=get(
            "cosoldering_constraint_jacobian_on_vec_f"
        ),
        cosoldering_gauge_map_sym=get("cosoldering_gauge_map_sym"),
        cosoldering_constraint_map_sym=get("cosoldering_constraint_map_sym"),
        candidate_coframe_4x4=get("candidate_coframe_4x4"),
        full_constrained_hessian=get("full_constrained_hessian"),
        full_constraint_map=get("full_constraint_map"),
        full_gauge_map=get("full_gauge_map"),
        expected_physical_dimension=scalar_from_json(
            config, "expected_physical_dimension"
        ),
    )

    report = results_to_jsonable(run_frontier(inputs))
    args.out.write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
