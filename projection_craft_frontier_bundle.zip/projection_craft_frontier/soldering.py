from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from .types import GateResult, GateStatus

Array = NDArray[np.float64]


def audit_coframe_rank(e: Array | None, tol: float = 1e-10) -> GateResult:
    if e is None:
        return GateResult(
            gate="A3",
            status=GateStatus.OPEN,
            statement="No independently varied candidate coframe matrix has been supplied.",
            witnesses=("MISSING-COFRAME-CANDIDATE",),
        )
    e = np.asarray(e, dtype=float)
    if e.shape != (4, 4):
        raise ValueError("coframe candidate must be a 4x4 coefficient matrix")
    det = float(np.linalg.det(e))
    rank = int(np.linalg.matrix_rank(e, tol))
    return GateResult(
        gate="A3",
        status=GateStatus.PASS if rank == 4 and abs(det) > tol else GateStatus.FAIL,
        statement="Exterior/soldering rank certificate N4 != 0 for an independently varied four-coframe.",
        residuals={"rank": rank, "determinant_N4": det},
        witnesses=() if rank == 4 and abs(det) > tol else ("DEGENERATE-COFRAME",),
    )
